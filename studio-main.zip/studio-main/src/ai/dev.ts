import { config } from 'dotenv';
config();

import '@/ai/flows/automated-triage.ts';